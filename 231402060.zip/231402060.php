<?php
    $koneksi = mysqli_connect('localhost', 'root', '', 'uas');

    if(isset($_POST['daftar'])){
        $email = $_POST['email'];
        $query = $koneksi->query("SELECT * FROM akun WHERE email = '$email'");
        $cek = $query->num_rows;
        if($cek>0){
            echo "Data Gagal Disimpan";
        } else{
            $name = $_POST['name'];
            $password = $_POST['password'];
            $q1 = "INSERT INTO akun(name, password, email) VALUES('$name', '$password', '$email')";
            $koneksi->query($q1);
        }


    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method = "POST">
    <label for = "email">Email</label><br>
    <input type = "email" name = "email"><br>
    <label for = "password">Password</label><br>
    <input type = "password" name = "password"><br><br>
    <label for = "name">Nama</label><br>
    <input type = "text" name = "name"><br><br>
    <button type = "submit" name = "daftar">Daftar</button>
</form>
</body>
</html>